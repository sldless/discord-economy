from .economy import Client
__name__ = "discord-economy"
__version__ = "0.0.2"
__author__ = "sldless"
__license__ = "MIT"
__support__ = 'https://discord.gg/GcHFjejEWR'